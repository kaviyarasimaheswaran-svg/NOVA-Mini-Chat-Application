from django.contrib.auth.models import User
from django.db import models

class ChatRoom(models.Model):
    user1 = models.ForeignKey(User, related_name="rooms_as_user1", on_delete=models.CASCADE)
    user2 = models.ForeignKey(User, related_name="rooms_as_user2", on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["user1", "user2"], name="unique_chat_pair")]

    def __str__(self):
        return f"{self.user1.username} - {self.user2.username}"

class Message(models.Model):
    room = models.ForeignKey(ChatRoom, related_name="messages", on_delete=models.CASCADE)
    sender = models.ForeignKey(User, related_name="sent_messages", on_delete=models.CASCADE)
    text = models.TextField(blank=True)
    attachment = models.FileField(upload_to="chat_files/%Y/%m/")
    attachment_name = models.CharField(max_length=255, blank=True)
    attachment_type = models.CharField(max_length=30, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["created_at"]

    def __str__(self):
        return f"{self.sender.username}: {(self.text or self.attachment_name)[:30]}"
