import json
from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import ChatRoom, Message

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope["user"]
        self.room_id = self.scope["url_route"]["kwargs"]["room_id"]
        self.group_name = f"chat_{self.room_id}"
        if self.user.is_anonymous or not await self.user_can_access_room():
            await self.close()
            return
        await self.channel_layer.group_add(self.group_name, self.channel_name)
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(self.group_name, self.channel_name)

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            message_text = data.get("message", "").strip()
        except (json.JSONDecodeError, TypeError):
            return
        if not message_text:
            return
        message = await self.save_message(message_text)
        await self.channel_layer.group_send(self.group_name, {"type": "chat_message", **message})

    async def chat_message(self, event):
        await self.send(text_data=json.dumps({
            "message": event.get("message", ""),
            "username": event["username"],
            "created_at": event["created_at"],
            "attachment_url": event.get("attachment_url", ""),
            "attachment_name": event.get("attachment_name", ""),
            "attachment_type": event.get("attachment_type", ""),
        }))

    @database_sync_to_async
    def user_can_access_room(self):
        try:
            room = ChatRoom.objects.get(id=self.room_id)
            return self.user.id in (room.user1_id, room.user2_id)
        except ChatRoom.DoesNotExist:
            return False

    @database_sync_to_async
    def save_message(self, text):
        room = ChatRoom.objects.get(id=self.room_id)
        msg = Message.objects.create(room=room, sender=self.user, text=text)
        return {"message": msg.text, "username": msg.sender.username,
                "created_at": msg.created_at.strftime("%H:%M")}
