from django.contrib import admin
from .models import ChatRoom, Message

@admin.register(ChatRoom)
class ChatRoomAdmin(admin.ModelAdmin):
    list_display=("id","user1","user2","created_at")

@admin.register(Message)
class MessageAdmin(admin.ModelAdmin):
    list_display=("id","room","sender","attachment_name","attachment_type","created_at")
    search_fields=("text","sender__username","attachment_name")
