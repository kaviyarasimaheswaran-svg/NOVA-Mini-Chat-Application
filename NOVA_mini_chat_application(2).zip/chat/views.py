from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

from .forms import RegisterForm
from .models import ChatRoom, Message

def register_view(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = RegisterForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        login(request, user)
        return redirect("home")
    return render(request, "register.html", {"form": form})

@login_required
def home(request):
    users = User.objects.exclude(id=request.user.id).order_by("username")
    return render(request, "home.html", {"users": users})

@login_required
def chat_room(request, username):
    other = get_object_or_404(User, username=username)
    if other == request.user:
        return redirect("home")
    u1, u2 = sorted([request.user, other], key=lambda u: u.id)
    room, _ = ChatRoom.objects.get_or_create(user1=u1, user2=u2)
    messages = room.messages.select_related("sender").all()
    return render(request, "chat_room.html", {"other": other, "room": room, "messages": messages})

@login_required
def upload_message(request, username):
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=405)

    other = get_object_or_404(User, username=username)
    if other == request.user:
        return JsonResponse({"error": "Invalid recipient"}, status=400)

    u1, u2 = sorted([request.user, other], key=lambda u: u.id)
    room, _ = ChatRoom.objects.get_or_create(user1=u1, user2=u2)
    uploaded = request.FILES.get("file")
    text = request.POST.get("message", "").strip()

    if not uploaded:
        return JsonResponse({"error": "No file selected"}, status=400)
    if uploaded.size > 25 * 1024 * 1024:
        return JsonResponse({"error": "File must be 25 MB or smaller"}, status=400)

    allowed = {
        "image": ["image/jpeg", "image/png", "image/gif", "image/webp"],
        "video": ["video/mp4", "video/webm", "video/quicktime"],
        "audio": ["audio/webm", "audio/ogg", "audio/mp4", "audio/mpeg", "audio/wav"],
        "document": ["application/pdf", "text/plain", "application/msword",
                     "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                     "application/vnd.ms-excel",
                     "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     "application/vnd.ms-powerpoint",
                     "application/vnd.openxmlformats-officedocument.presentationml.presentation"],
    }
    kind = next((k for k, types in allowed.items() if uploaded.content_type in types), None)
    if not kind:
        return JsonResponse({"error": "Unsupported file type"}, status=400)

    msg = Message.objects.create(
        room=room, sender=request.user, text=text,
        attachment=uploaded, attachment_name=uploaded.name, attachment_type=kind
    )
    event = {
        "message": msg.text,
        "username": request.user.username,
        "created_at": msg.created_at.strftime("%H:%M"),
        "attachment_url": msg.attachment.url,
        "attachment_name": msg.attachment_name,
        "attachment_type": msg.attachment_type,
    }
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(f"chat_{room.id}", {"type": "chat_message", **event})
    return JsonResponse(event)
