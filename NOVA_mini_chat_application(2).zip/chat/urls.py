from django.contrib.auth import views as auth_views
from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("register/", views.register_view, name="register"),
    path("login/", auth_views.LoginView.as_view(template_name="login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("chat/<str:username>/", views.chat_room, name="chat_room"),
    path("chat/<str:username>/upload/", views.upload_message, name="upload_message"),
]
