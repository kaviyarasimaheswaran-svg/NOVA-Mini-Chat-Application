from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [("chat", "0001_initial")]
    operations = [
        migrations.AddField(
            model_name="message", name="attachment",
            field=models.FileField(blank=True, upload_to="chat_files/%Y/%m/"),
        ),
        migrations.AddField(
            model_name="message", name="attachment_name",
            field=models.CharField(blank=True, max_length=255),
        ),
        migrations.AddField(
            model_name="message", name="attachment_type",
            field=models.CharField(blank=True, max_length=30),
        ),
    ]
