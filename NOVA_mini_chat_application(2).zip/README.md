# NOVA — Mini Social Chat

A redesigned Django + Channels real-time chat app with a clean, cute-but-professional social messaging interface.

## Included
- One-to-one real-time WebSocket chat
- Text messages with persistent SQLite storage
- Emoji picker for sending emoji messages
- Image sharing with previews
- Video sharing with in-chat playback
- PDF and common document sharing
- Voice-note recording from the browser and playback
- 25 MB upload limit
- Responsive desktop/mobile UI
- Django authentication and admin
- No decorative emoji icons in the main interface; controls use minimal text/symbol styling

## Run on Windows

```bat
cd path\to\NOVA_mini_chat_application
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open `http://127.0.0.1:8000/`.

To test real-time messaging, register two accounts and open the two chats in separate browser windows.

## File sharing
Click the attachment button to select an image, video, PDF, Word/Excel/PowerPoint file, or text document.

Click the voice button once to start recording and again to stop and send. Your browser will ask for microphone permission.

## Notes
This development build uses Django Channels' in-memory layer. For production/multiple server processes, use Redis and a production ASGI server. Configure HTTPS/WSS and production media storage before publishing publicly.
